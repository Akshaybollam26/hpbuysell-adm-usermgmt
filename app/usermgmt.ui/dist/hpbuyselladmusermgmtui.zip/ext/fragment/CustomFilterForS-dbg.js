sap.ui.define([
    "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/m/Token", "sap/m/Text", "sap/m/Column", "sap/m/ColumnListItem", "sap/ui/table/Column"
], function (Filter, FilterOperator, Token, Text, Column, ColumnListItem, UITableColumn) {
    "use strict";
    const Handler = {
        _oMultiInput: null,
        onValueHelpRequest: function (oEvent) {
            Handler._oMultiInput = oEvent.getSource();
            const oModel = Handler._oMultiInput.getModel(),
                sTitle = "Select Suppliers",
                sPath = "commonServiceModel>/SupplierVH",
                sKey = "commonServiceModel>supplierid",
                sText = "commonServiceModel>suppliername";
            sap.ui.require(["sap/ui/comp/valuehelpdialog/ValueHelpDialog"], function (ValueHelpDialog) {
                const oDialog = new ValueHelpDialog({
                    title: sTitle,
                    supportMultiselect: true,
                    supportRanges: false,
                    key: sKey,
                    descriptionKey: sText,
                    ok: function (oEvent) {
                        const aTokens = oEvent.getParameter("tokens") || [];
                        Handler._oMultiInput.setTokens(aTokens);
                        Handler._updateFilterValue(aTokens);
                        oDialog.close();
                    },
                    cancel: function () { oDialog.close(); },
                    afterClose: function () { oDialog.destroy(); }
                });
                oDialog.setTokens(Handler._oMultiInput.getTokens().map(function (oToken) {
                    return new Token({ key: oToken.getKey() });
                }));
                oDialog.setModel(oModel);
                oDialog.getTableAsync().then(function (oTable) {
                    oTable.setModel(oModel);
                    if (oTable.bindRows) {
                        oTable.removeAllColumns();
                        oTable.addColumn(new UITableColumn({
                            label: new Text({ text: "Supplier ID" }),
                            template: new Text({ text: "{" + sKey + "}" }),
                            sortProperty: sKey,
                            filterProperty: sKey
                        }));
                        oTable.addColumn(new UITableColumn({
                            label: new Text({ text: "Supplier Name" }),
                            template: new Text({ text: "{" + sText + "}" }),
                            sortProperty: sText,
                            filterProperty: sText
                        }));
                        oTable.bindRows({ path: sPath });
                    } else {
                        oTable.removeAllColumns();
                        oTable.addColumn(new Column({ header: new Text({ text: "Supplier ID" }) }));
                        oTable.addColumn(new Column({ header: new Text({ text: "Supplier Name" }) }));
                        oTable.bindItems({
                            path: sPath,
                            template: new ColumnListItem({
                                cells: [
                                    new Text({ text: "{" + sKey + "}" }),
                                    new Text({ text: "{" + sText + "}" })
                                ]
                            })
                        });
                    }
                    oDialog.update();
                });
                oDialog.open();
            });
        },
        onTokenUpdate: function (oEvent) {
            setTimeout(function () { Handler._updateFilterValue(oEvent.getSource().getTokens()); }, 0);
        },
        _updateFilterValue: function (aTokens) {
            Handler._oMultiInput.setValue(aTokens.map(function (oToken) { return oToken.getKey(); }).join(","));
        },

        /*
         * Filters on suppliers/partnerId - NOT customers/partnerId.
         * This is what was missing: this file previously either had no
         * filterItems implementation matching this path, or still
         * referenced the customer navigation path copied from
         * CustFilter.js.
         */
        filterItems: function (sValue) {
            if (!sValue) return null;
            const aIds = sValue.split(",").map(function (s) { return s.trim(); }).filter(Boolean);
            if (!aIds.length) return null;
            return new Filter({
                filters: aIds.map(function (sId) {
                    return new Filter({
                        path: "suppliers/partnerId",
                        operator: FilterOperator.EQ,
                        value1: sId
                    });
                }),
                and: false
            });
        }
    };
    return Handler;
});
